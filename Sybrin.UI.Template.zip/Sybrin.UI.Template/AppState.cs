﻿using $safeprojectname$.PropertyClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$ {
    /// <summary>
    /// Static class used to access global variables, events, etc.
    /// </summary>
    public static class AppState {
        /// <summary>
        /// Boolean value to see if the Object is created from WindowsUI Deserializing the parameter string, which will call the constructor. 
        /// In some cases you do not want some logic in the constructor to be executed multiple times, and should only be executed once. 
        /// This variable can be used to make suure some logic only executes once (for instance, subscribing to Events)
        /// </summary>
        public static bool IsDeserializedInitialization = true;

        /// <summary>
        /// Centralized location to get the File Name for normal logging.
        /// </summary>
        public static string LogInfo = "CustomControl";

        /// <summary>
        /// Centralized location to get the File Name for Exception Logging
        /// </summary>
        public static string LogError = "CustomControl.Exceptions";

        /// <summary>
        /// The Instance of the Sybrin Client, accessable globally.
        /// </summary>
        public static Client.Client SybrinClient { get; set; }

        /// <summary>
        /// The Properties of your Control, accessable globally.
        /// </summary>
        public static TemplateControlProperties Properties { get; set; }

        /// <summary>
        /// Event to force the PropertyGrid to refresh
        /// </summary>
        public static event EventHandler<PropertyChangedEventArgs> RefreshGrid = null;
        /// <summary>
        /// Raise the event to force the PropertyGrid of the Test Application to refresh.
        /// </summary>
        /// <param name="sender">The object the raise event originated from</param>
        /// <param name="e">The Event Arguments that will be passed to the event.</param>
        public static void RaiseRefreshGrid(object sender, PropertyChangedEventArgs e) {
            RefreshGrid?.Invoke(sender, e);
        }

    }
}
