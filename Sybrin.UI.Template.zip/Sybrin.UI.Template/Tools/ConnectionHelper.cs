﻿using $safeprojectname$.PropertyClasses;
using System;
using System.Threading.Tasks;
using System.Windows;

namespace $safeprojectname$.Tools {
    public static class ConnectionHelper {
        public static void ConnectClient(Action<bool?, string> SetBusy, Action PostInitialise, TemplateControlProperties Properties) {
            try {
                if (AppState.SybrinClient == null) {
                    SetBusy?.Invoke(true, "Initialising Sybrin Client");
                    AppState.SybrinClient = new Client.Client();
                }
            } catch (Exception ex) {
                throw new Exception("Error setting Sybrin Client", ex);
            }
            Task.Factory.StartNew(() => {
                try {
                    if (Properties.IsTesting && (AppState.SybrinClient == null || !AppState.SybrinClient.LoggedOn)) {
                        "Sybrin Client Logging on...".CustomLog();
                        if (Client.Globals.SybrinClient == null || !Client.Globals.SybrinClient.LoggedOn) {
                            SetBusy?.Invoke(true, "Sybrin Client Logging on...");
                            var conn = Properties.ConnectionProperties;
                            AppState.SybrinClient.Logon(Common.SybrinModule.Scheduler, conn.Username, conn.Password, conn.Server, conn.Port);
                            "Sybrin Client Logged on.".CustomLog();
                        }
                    }
                } catch (Exception ex) {
                    throw new Exception("Error logging on", ex);
                }
            }).ContinueWith((t) => {
                try {
                    if (t.Exception == null) {
                        SetBusy?.Invoke(false, "Sybrin Client Connected...");
                    } else {
                        var ex = t.Exception.InnerException;
                        ex.CustomLog("Failed to Connect Client");
                        MessageBox.Show($"Failed to connect the Sybrin Client: {ex.Message}", "Failed to connect to Sybrin");
                    }
                    PostInitialise?.Invoke();
                } catch (Exception ex) {
                    ex.CustomLog();
                }
            });
        }

        public static void ConnectClientSynchronously(Action<bool?, string> SetBusy, Action PostInitialise, TemplateControlProperties Properties) {
            try {
                if (AppState.SybrinClient == null) {
                    SetBusy?.Invoke(true, "Initialising Sybrin Client");
                    AppState.SybrinClient = new Client.Client();
                }
            } catch (Exception ex) {
                throw new Exception("Error setting Sybrin Client", ex);
            }
            try {
                if (Properties.IsTesting && (AppState.SybrinClient == null || !AppState.SybrinClient.LoggedOn)) {
                    "Sybrin Client Logging on...".CustomLog();
                    if (Client.Globals.SybrinClient == null || !Client.Globals.SybrinClient.LoggedOn) {
                        var conn = Properties.ConnectionProperties;
                        AppState.SybrinClient.Logon(Common.SybrinModule.Scheduler, conn.Username, conn.Password, conn.Server, conn.Port);
                        "Sybrin Client Logged on.".CustomLog();
                        PostInitialise?.Invoke();
                    }
                }
            } catch (Exception ex) {
                throw new Exception("Error logging on", ex);
            }
        }
    }
}
