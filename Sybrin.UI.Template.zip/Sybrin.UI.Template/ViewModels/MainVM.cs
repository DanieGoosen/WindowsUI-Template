﻿using $safeprojectname$.BaseClasses;
using $safeprojectname$.PropertyClasses;
using $safeprojectname$.Tools;
using System;
using System.Diagnostics;
using System.Threading.Tasks;

namespace $safeprojectname$.ViewModels {
    public class MainVM : BaseViewModel {

        public MainVM() {
        }

        public void Initialise() {
            Task.Factory.StartNew(() => {
                "Initialising...".CustomLog();
                IsBusy = true;
                BusyContent = "Initialising...";
                ConnectionHelper.ConnectClient(SetBusy, postInitialise, Properties);
            });
        }

        private void postInitialise() {
            Task.Factory.StartNew(() => {
                try {
                    // Initialise your component models over here.
                    TestString = Properties.HelloWorld;
                    SetBusy(true, "Performing Post Initialising Tasks...");
                } catch (Exception ex) {
                    new Exception("Failed to run Postinitialize tasks on MainVM", ex).CustomLog();
                }
            }).ContinueWith((t) => {
                SetBusy(false, "Finished Post Initialising Tasks");
            });
        }

        private string testString = "";
        /// <summary>
        /// Gets or sets the Test String used for Testing DataContext
        /// </summary>

        public string TestString {
            [DebuggerNonUserCode]
            get { return this.testString; }
            [DebuggerNonUserCode]
            set {
                if (this.testString != value) {
                    this.testString = value;
                    SetPropertyChanged("TestString");
                }
            }
        }

        private TemplateControlProperties properties;
        public TemplateControlProperties Properties {
            get { return properties; }
            set {
                if (properties != value) {
                    properties = value;
                    AppState.Properties = value;
                }
            }
        }
    }
}
