﻿using Sybrin.Extensions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace $safeprojectname$ {
    public static class Extensions {

        /// <summary>
        /// Logs to the SimpleLogs folder for this Control.
        /// </summary>
        /// <param name="message">The message that should be included in the log</param>
        public static void CustomLog(this string message) {
            message.SimpleLog(AppState.LogInfo);
        }

        /// <summary>
        /// The Exception to be logged. 
        /// </summary>
        /// <param name="ex">The Exception to log</param>
        /// <param name="message">The additional information you want to log with the exception message</param>
        /// <param name="showMessage">If a message should be shown when the error is thrown</param>
        public static void CustomLog(this Exception ex, string message = "", bool showMessage = false) {
            var msg = $"{(message.isNullOrEmpty() ? "" : $"{message} - ")}{ex.ToString()}";
            msg.SimpleLog(AppState.LogError);
            if ((AppState.Properties?.IsTesting ?? false) || showMessage)
                MessageBox.Show(msg, "Error occured");
        }
    }
}
