﻿using $safeprojectname$.Tools;
using Sybrin10.Kernel.Attributes;
using Sybrin10.Kernel.BaseClasses;
using System;
using System.ComponentModel;
using System.Diagnostics;

namespace $safeprojectname$.PropertyClasses {
    public class ConnectionProperties : CustomDescriptorBase, INotifyPropertyChanged {
        public ConnectionProperties() {

        }

        private string username = "admin";
        /// <summary>
        /// Gets or sets the Username to use
        /// </summary>
        [Category("1 - General"), Description("Sets the Username to use")]
        [DefaultValue("admin")]
        [DisplayName("1 - Username")]
        public string Username {
            [DebuggerNonUserCode]
            get { return this.username; }
            [DebuggerNonUserCode]
            set {
                if (this.username != value) {
                    this.username = value;
                }
            }
        }

        private string password = "";
        /// <summary>
        /// Gets or sets the Password
        /// </summary>
        [Category("1 - General"), Description("Sets the Password")]
        [DefaultValue("")]
        [DisplayName("2 - Password")]
        public string Password {
            [DebuggerNonUserCode]
            get { return this.password; }
            [DebuggerNonUserCode]
            set {
                if (this.password != value) {
                    this.password = value;
                }
            }
        }

        private string server = "";
        /// <summary>
        /// Gets or sets the Server
        /// </summary>
        [Category("1 - General"), Description("Sets the Server")]
        [DefaultValue("")]
        [DisplayName("3 - Server")]
        public string Server {
            [DebuggerNonUserCode]
            get { return this.server; }
            [DebuggerNonUserCode]
            set {
                if (this.server != value) {
                    this.server = value;
                }
            }
        }

        private int port = 1050;
        /// <summary>
        /// Gets or sets the Port
        /// </summary>
        [Category("1 - General"), Description("Sets the Port")]
        [DefaultValue(1050)]
        [DisplayName("4 - Port")]
        public int Port {
            [DebuggerNonUserCode]
            get { return this.port; }
            [DebuggerNonUserCode]
            set {
                if (this.port != value) {
                    this.port = value;
                }
            }
        }

        private bool isConnected = false;
        /// <summary>
        /// Gets or sets the Client is connected or not
        /// </summary>
        [Category("1 - General"), Description("Sets the Client is connected or not")]
        [DefaultValue(false)]
        [DisplayName("5 - Connected")]
        public bool IsConnected {
            [DebuggerNonUserCode]
            get { return this.isConnected; }
            [DebuggerNonUserCode]
            set {
                if (this.isConnected != value) {
                    this.isConnected = value;
                    if (value && AppState.Properties != null) {
                        try {
                            ConnectionHelper.ConnectClientSynchronously(null, null, AppState.Properties);
                            Exception = null;
                        } catch (Exception ex) {
                            Client.Globals.SybrinClient = null;
                            Exception = ex;
                            isConnected = false;
                        }
                    } else if (!value) {
                        AppState.SybrinClient = null;
                        Client.Globals.SybrinClient = null;
                    }

                    HasException = Exception != null;
                }
            }
        }

        private bool hasException = false;
        [Browsable(false)]
        public bool HasException {
            [DebuggerNonUserCode]
            get { return this.hasException; }
            set {
                if (this.hasException != value) {
                    this.hasException = value;
                    SetPropertyChanged("HasException");
                }
            }
        }

        private Exception exception = null;
        /// <summary>
        /// Gets or sets the Exception that occured when the client failed to connect
        /// </summary>
        [Category("1 - General"), Description("Sets the Exception that occured when the client failed to connect")]
        [DefaultValue(null)]
        [DisplayName("5.2 - Exception")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        [DynamicPropertyFilter("HasException", "True")]
        public Exception Exception {
            [DebuggerNonUserCode]
            get { return this.exception; }
            [DebuggerNonUserCode]
            set {
                if (this.exception != value) {
                    this.exception = value;
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void SetPropertyChanged(string propName) {
            var handler = PropertyChanged;
            if (handler != null) {
                handler.Invoke(this, new PropertyChangedEventArgs(propName));
            } else {
                // Hack to force the PropertyGrid to refresh
                AppState.RaiseRefreshGrid(this, null);
            }
        }

        public override string ToString() {
            return "[Connection Properties]";
        }
    }
}
