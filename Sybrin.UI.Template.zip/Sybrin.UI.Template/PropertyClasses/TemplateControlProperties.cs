﻿using Sybrin10.Dynamic;
using Sybrin10.Kernel.Attributes;
using Sybrin10.Kernel.BaseClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.PropertyClasses {
    public class TemplateControlProperties : CustomDescriptorBase, INotifyPropertyChanged {
        #region Constructors

        public TemplateControlProperties() {

        }

        #endregion Constructors

        #region Properties
        
        private bool isTesting = false;
        /// <summary>
        /// Gets or sets the Testing variable. This should be true if the app is launched from the TestApp, to enable additional properties required to connect the client.
        /// </summary>
        [Browsable(false)]
        public bool IsTesting {
            [DebuggerNonUserCode]
            get { return this.isTesting; }
            [DebuggerNonUserCode]
            set {
                if (this.isTesting != value) {
                    this.isTesting = value;
                    SetPropertyChanged("IsTesting");
                }
            }
        }

        private string configFile = "";
        /// <summary>
        /// Gets or sets the Path to the Saved Configuration File to load the saved properties from.
        /// </summary>
        [Category("99 - Misc"), Description("Sets the Path to the Saved Configuration File")]
        [DefaultValue("")]
        [DisplayName("0 - Config File Path")]
        [ReadOnly(true)]
        public string ConfigFile {
            [DebuggerNonUserCode]
            get { return this.configFile; }
            [DebuggerNonUserCode]
            set {
                if (this.configFile != value) {
                    this.configFile = value;
                }
            }
        }

        private string helloWorld = "Hello world!";
        /// <summary>
        /// Gets or sets the Hello World String, only used for testing.
        /// Note: This Variable can be removed.
        /// </summary>
        [Category("99 - Misc"), Description("Sets the Hello World String")]
        [DefaultValue("Hello world!")]
        [DisplayName("1 - Hello World!")]
        public string HelloWorld {
            get { return this.helloWorld; }
            set {
                if (this.helloWorld != value) {
                    this.helloWorld = value;
                }
            }
        }

        private ConnectionProperties connectionProperties = new ConnectionProperties();
        /// <summary>
        /// Gets or sets the Connection Properties for Testing
        /// </summary>
        [Category("99 - Misc"), Description("Sets the Connection Properties for Testing")]
        [DefaultValue(null)]
        [DisplayName("2 - Connection Properties")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        [DynamicPropertyFilter("IsTesting", "True")]
        public ConnectionProperties ConnectionProperties {
            [DebuggerNonUserCode]
            get { return this.connectionProperties; }
            [DebuggerNonUserCode]
            set {
                if (this.connectionProperties != value) {
                    this.connectionProperties = value;
                }
            }
        }

        #endregion Properties

        #region Events

        public event PropertyChangedEventHandler PropertyChanged;
        public void SetPropertyChanged(string propName) {
            var handler = PropertyChanged;
            if (handler != null) {
                handler.Invoke(this, new PropertyChangedEventArgs(propName));
            }
        }

        #endregion Events

        #region Methods

        public override string ToString() {
            return "[Properties]";
        }

        #endregion Methods

    }
}
