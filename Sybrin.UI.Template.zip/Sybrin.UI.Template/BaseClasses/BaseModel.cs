﻿using Newtonsoft.Json;
using Sybrin10.Kernel.BaseClasses;
using System;
using System.ComponentModel;
using System.Windows.Input;
using System.Xml.Serialization;

namespace $safeprojectname$.BaseClasses {
    public class BaseModel : INotifyPropertyChanged {
        #region Constructors
        public BaseModel() {

        }
        #endregion

        #region Properties

        public string LogInfo { get { return AppState.LogInfo; } }
        public string LogError { get { return AppState.LogError; } }

        [JsonIgnore, XmlIgnore]
        private Action CloseAction;
        public void Close() {
            CloseAction?.Invoke();
        }

        private bool isBusy = false;
        /// <summary>
        /// Gets or sets the busy status of the model
        /// </summary>

        public bool IsBusy {
            get { return this.isBusy; }
            set {
                if (this.isBusy != value) {
                    this.isBusy = value;
                    SetPropertyChanged("IsBusy");
                }
            }
        }

        private string busyContent = "";
        /// <summary>
        /// Gets or sets the content of the indicator when it is busy
        /// </summary>

        public string BusyContent {
            get { return this.busyContent; }
            set {
                if (this.busyContent != value) {
                    this.busyContent = value;
                    SetPropertyChanged("BusyContent");
                }
            }
        }
        #endregion

        #region Methods
        public void ExecuteOnViewModelThread(Action action) {
            System.Windows.Application.Current.Dispatcher.Invoke(action);
        }

        public void ExecuteOnViewModelThreadAsync(Action action) {
            System.Windows.Application.Current.Dispatcher.BeginInvoke(action, null);
        }

        public ICommand CreateCommand(Action<object> executeAction, Func<object, bool> canExecuteFunction = null) {
            if (executeAction == null)
                throw new ArgumentNullException("executeAction");

            return canExecuteFunction == null ? new SimpleCommand(executeAction) : new SimpleCommand(executeAction, canExecuteFunction);
        }
        #endregion

        #region Event Handler
        public event PropertyChangedEventHandler PropertyChanged;
        public void SetPropertyChanged(string propName) {
            var handler = PropertyChanged;
            if (handler != null) {
                handler.Invoke(this, new PropertyChangedEventArgs(propName));
            }
        }
        #endregion
    }
}
