﻿using Newtonsoft.Json;
using Sybrin10.Kernel.BaseClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Input;
using System.Xml.Serialization;

namespace $safeprojectname$.BaseClasses {
    public class BaseViewModel : INotifyPropertyChanged, IDisposable {
        #region Constructors

        #endregion

        #region Properties

        public string ID { get; } = Guid.NewGuid().ToString();

        public string LogInfo { get { return AppState.LogInfo; } }
        public string LogError { get { return AppState.LogError; } }

        /// <summary>
        /// The action that must be executed when the ViewModel is Disposed
        /// </summary>
        [XmlIgnore, JsonIgnore]
        private Action CloseAction;
        public void Close() {
            CloseAction?.Invoke();
        }

        private bool isBusy = false;
        /// <summary>
        /// Gets or sets the Busy Status of the ViewModel
        /// </summary>

        [XmlIgnore, JsonIgnore]
        public bool IsBusy {
            get { return this.isBusy; }
            set {
                if (this.isBusy != value) {
                    this.isBusy = value;
                    SetPropertyChanged("IsBusy");
                }
            }
        }

        [XmlIgnore, JsonIgnore]
        private string busyContent = "";
        /// <summary>
        /// Gets or sets the Content to be displayed when the ViewModel is Busy
        /// </summary>

        public string BusyContent {
            get { return this.busyContent; }
            set {
                if (this.busyContent != value) {
                    this.busyContent = value;
                    SetPropertyChanged("BusyContent");
                }
            }
        }

        #endregion

        #region Events
        public event PropertyChangedEventHandler PropertyChanged;
        public void SetPropertyChanged(string propName) {
            var handler = PropertyChanged;
            if (handler != null) {
                handler.Invoke(this, new PropertyChangedEventArgs(propName));
            }
        }
        #endregion

        #region Methods
        public void Dispose() {
            CloseAction?.Invoke();
        }

        public void SetBusy(bool? isBusy, string message = "") {
            if (message != "") {
                this.BusyContent = message;
                message.CustomLog();
            }
            if (IsBusy && (!isBusy ?? false))
                Thread.Sleep(150);
            if (isBusy != null) {
                this.IsBusy = (isBusy ?? false);
            }
        }

        public void ExecuteOnViewModelThread(Action action) {
            System.Windows.Application.Current.Dispatcher.Invoke(action);
        }

        public void InvokeOnUIThread(Action action) {
            ExecuteOnViewModelThread(action);
        }

        public void ExecuteOnViewModelThreadAsync(Action action) {
            System.Windows.Application.Current.Dispatcher.BeginInvoke(action, null);
        }

        public ICommand CreateCommand(Action<object> executeAction, Func<object, bool> canExecuteFunction = null) {
            if (executeAction == null)
                throw new ArgumentNullException("executeAction");
            return canExecuteFunction == null ? new SimpleCommand(executeAction) : new SimpleCommand(executeAction, canExecuteFunction);
        }
        #endregion
    }
}
