﻿using System;
using System.ComponentModel;
using System.Windows.Forms;
using System.ComponentModel.Composition;
using Sybrin10.Windows.UI;
using Sybrin10.Kernel.BaseClasses;
using $safeprojectname$.PropertyClasses;
using Sybrin.Client.Attributes;
using System.Diagnostics;
using Newtonsoft.Json;
using System.Xml.Serialization;
using $safeprojectname$.ViewModels;
using Sybrin.Common;
using System.Windows;
using $safeprojectname$.Views;

namespace $safeprojectname$ {
    [Export("$safeprojectname$.TemplateControl", typeof(ICustomControl))]
    [ExportMetadata("Description", "Template Control")]
    public partial class TemplateControl : UserControl, ICustomControl, INotifyPropertyChanged {
        public TemplateControl() {
            // Only attach after the control has been deserialized.
            if (!AppState.IsDeserializedInitialization) {
                InitializeComponent();
                attachEvents();
                AppState.Properties = this.properties;
            }
            AppState.IsDeserializedInitialization = false;
            ApplicationObjectName = "$safeprojectname$";
            ApplicationPath = Environment.SpecialFolder.LocalApplicationData;
            ObjectClassName = "TemplateControl";
            ControlPanelTitle = "Template Control";
            ControlStartPosition = Sybrin10.Windows.DockingState.DockLeft;
            SubFolder = @"Sybrin\bin\$safeprojectname$.dll";
        }

        /// <summary>
        /// The Configurable Properties of your Control. 
        /// </summary>
        private TemplateControlProperties properties = new TemplateControlProperties();
        [DisplayName(" 0 - Properties")]
        [Category("0 - Control Properties")]
        [Description("Main Properties for the Control")]
        [TypeConverter(typeof(ExpandableObjectConverter))]
        public PropertyBase Properties {
            get {
                return properties;
            }

            set {
                if (properties != value) {
                    properties = (TemplateControlProperties)value;
                }
            }
        }

        #region WindowsUI Properties

        /// <summary>
        /// The title the Panel will have in WindowsUI for the control
        /// </summary>
        [Category("0 - Control Properties")]
        [DisplayName(" 1 - Control Title")]
        [Description("The title the Panel will have in WindowsUI for the control")]
        public string ControlPanelTitle { get; set; }

        /// <summary>
        /// The Starting Position WindowsUI will use to determine where the control should be placed (Default: Docked)
        /// </summary>
        [Category("0 - Control Properties")]
        [DisplayName(" 2 - Control Start Position")]
        [Description("The Startup Position of the Panel")]
        [DefaultValue(Sybrin10.Windows.DockingState.DockLeft)]
        public Sybrin10.Windows.DockingState ControlStartPosition { get; set; }

        /// <summary>
        /// The Namespace where your Object can be located, for MEF loading.
        /// </summary>
        [Category("0 - Control Properties")]
        [DisplayName(" 3 - Application Object Name")]
        [Description("The Namespace where your Object can be located, for MEF loading")]
        [ReadOnly(true)]
        public string ApplicationObjectName { get; set; }

        /// <summary>
        /// The Location where this assembly should be loaded from.
        /// </summary>
        [Category("0 - Control Properties")]
        [DisplayName(" 4 - Application Path")]
        [Description("The Location where this assembly should be loaded from")]
        [ReadOnly(true)]
        public Environment.SpecialFolder ApplicationPath { get; set; }

        /// <summary>
        /// The name of the Object (Case Sensitive) in the namespace as indicated through 'Application Object Name'
        /// </summary>
        [Category("0 - Control Properties")]
        [DisplayName(" 5 - Object Class Name")]
        [ReadOnly(true)]
        [Description("The name of the Object (Case Sensitive) in the namespace as indicated through 'Application Object Name'")]
        public string ObjectClassName { get; set; }

        /// <summary>
        /// The Folder location from the 'ApplicationPath' (These two are appended to find the assembly)
        /// </summary>
        [Category("0 - Control Properties")]
        [DisplayName(" 6 - Sub Folder")]
        [ReadOnly(true)]
        [Description("The Second part of the File Path where the Assembly will be found. This is appended from the 'ApplicationPath'")]
        public string SubFolder { get; set; }

        #endregion

        #region WindowsUI Bindable Properties

        private Client.Client sybrinClient;
        [Browsable(false), XmlIgnore(), BindableControl]
        public Client.Client SybrinClient {
            get { return sybrinClient; }
            set {
                if (value != sybrinClient) {
                    AppState.SybrinClient = value;
                    sybrinClient = value;
                }
            }
        }

        private AllocItem selectedAllocItem;
        /// <summary>
        /// Gets or sets the selected alloc item.
        /// </summary>
        /// <value>The selected alloc item.</value>
        [Browsable(false), XmlIgnore(), JsonIgnore, BindableControl]
        public AllocItem SelectedAllocItem {
            get { return selectedAllocItem; }
            set {
                if (value != selectedAllocItem) {
                    selectedAllocItem = value;
                }
            }
        }

        private AllocResult allocResult;
        [Browsable(false), XmlIgnore(), BindableControl]
        public AllocResult AllocResult {
            get { return allocResult; }
            set {
                if (value != allocResult) {
                    allocResult = value;
                }
            }
        }

        #endregion

        #region Properties

        public bool HasLoaded { get; set; }// = false;

        [XmlIgnore(), JsonIgnore(), Browsable(false)]
        public MainVM MainVM { get; set; }
        #endregion

        #region Events

        public event PropertyChangedEventHandler PropertyChanged;
        public void SetPropertyChanged(string propName) {
            var handler = PropertyChanged;
            if (handler != null) {
                handler.Invoke(this, new PropertyChangedEventArgs(propName));
            }
        }


        #endregion

        #region Methods

        #region private Methods

        /// <summary>
        /// This control will load your view in the WindowsUI tab.
        /// Note: A new View will be created every time this function is called, and might break the DataContext when this happens. Be carefull when you call this function.
        /// </summary>
        private void loadControl() {
            try {
                var winUIControlHost = new System.Windows.Forms.Integration.ElementHost();
                var mainView = new MainView();
                mainView.DataContext = MainVM;
                this.SuspendLayout();
                //
                // elementHost1
                //
                winUIControlHost.Dock = DockStyle.Fill;
                winUIControlHost.Location = new System.Drawing.Point(0, 0);
                winUIControlHost.Name = "elementHost1";
                winUIControlHost.Size = new System.Drawing.Size(376, 577);
                winUIControlHost.TabIndex = 0;
                winUIControlHost.Text = "elementHost1";
                winUIControlHost.Child = mainView;
                
                AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
                AutoScaleMode = AutoScaleMode.Font;
                Controls.Clear();
                Controls.Add(winUIControlHost);
                Name = "DynamicFields";
                Size = new System.Drawing.Size(376, 577);
                ResumeLayout(false);
                winUIControlHost.Refresh();
                this.Size = new System.Drawing.Size(this.Width + 1, this.Height + 1);
            } catch {
                throw;
            }
        }

        /// <summary>
        /// Listens/subscribes to events, when the control should be validated, updated, disposed, etc.
        /// </summary>
        private void attachEvents() {
            try {
                detachEvents();

                Disposed += OnDisposed;
                "Attaching Events to Control...".CustomLog();
            } catch (Exception ex) {
                ex.CustomLog("Failed to attach events");
            }
        }

        private void OnDisposed(object sender, EventArgs e) {
            try {
                AppState.IsDeserializedInitialization = true; // Make sure the Next time the constructor is called, will be from Deserialization
                HasLoaded = false;
                "Disposing Control...".CustomLog();

                detachEvents();
            } catch (Exception ex) {
                ex.CustomLog();
            }
        }

        /// <summary>
        /// Detaches events that should be disposed of. Any Event that is attachemd multiple times will drastically slow down the control
        /// </summary>
        private void detachEvents() {
            try {
                "Detaching Events from Control...".CustomLog();
            } catch {
                throw;
            }
        }

        private void startApplication() {
            try {
                if (System.Windows.Application.Current == null) {
                    "Initialising Application with Explicit Shutdown Mode".CustomLog();
                    new System.Windows.Application() { ShutdownMode = System.Windows.ShutdownMode.OnExplicitShutdown };
                    System.Windows.Application.Current.Exit += Current_Exit;
                }
            } catch (Exception ex) {
                ex.CustomLog("Failed to start an instance of the Application in the App Domain");
            }
        }

        private void Current_Exit(object sender, ExitEventArgs e) {
            OnDisposed(this, null);
        }
        #endregion

        #region public Methods

        /// <summary>
        /// The First Method WindowsUI will hit when the control should be loaded.
        /// Initialize your logic from the MainVM over here, where the saved properties are loaded from the ComponentProperties class
        /// </summary>
        public void LoadUserControl() {
            try {
                startApplication();
                MainVM = new MainVM();
                MainVM.TestString = properties.HelloWorld;

                loadControl();
            } catch (Exception ex) {
                ex.CustomLog("Failed to load the User Control");
            }
        }

        public override string ToString() {
            return "Template Control";
        }
        #endregion

        #endregion


    }
}
