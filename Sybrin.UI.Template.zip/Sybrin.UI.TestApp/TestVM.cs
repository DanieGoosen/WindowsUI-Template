﻿using Sybrin.UI.Template;
using Sybrin.UI.Template.BaseClasses;
using Sybrin.UI.Template.PropertyClasses;
using Sybrin.UI.Template.ViewModels;
using Sybrin10.Extensions;
using Sybrin10.Kernel;
using Sybrin10.Kernel.BaseClasses;
using Sybrin10.Windows;
using System;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace $safeprojectname$ {
    public class TestVM : BaseViewModel {
        #region Constructors

        public TestVM() {
            ConfigFile = System.IO.Path.Combine(this.Path, $"{ID}.txt");
        }

        public TestVM(MainVM mainVM, EnhancedPropertyGrid propertyGrid) : this() {
            this.PropertyGrid = propertyGrid;
            this.MainVM = mainVM;
            AppState.RefreshGrid += (o, e) => { this.PropertyGrid.Refresh(); };
            addControls(PropertyGrid);
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// File Name that the Config will be saved in.
        /// NOTE: Change this guid to a new one with every project, otherwise you will override your locally saved Configuration
        /// </summary>
        public new string ID { get; set; } = "C9AB300F-6892-4BCB-BDC5-4FED6D0F2166";

        /// <summary>
        /// Path to the Config File
        /// </summary>
        public string Path { get; set; } = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);

        /// <summary>
        /// Full Path to the config File.
        /// </summary>
        public string ConfigFile { get; set; }

        /// <summary>
        /// PropertyGrid object to access its SelectedObject
        /// </summary>
        public EnhancedPropertyGrid PropertyGrid { get; set; }

        private TemplateControlProperties properties = new TemplateControlProperties();
        /// <summary>
        /// Gets or sets the Properties object used to configure your component
        /// </summary>
        public PropertyBase Properties {
            [DebuggerNonUserCode]
            get { return this.properties; }
            [DebuggerNonUserCode]
            set {
                if (this.properties != value) {
                    this.properties = (TemplateControlProperties)value;
                }
            }
        }

        #region INotify Properties

        private MainVM mainVM = new MainVM();
        /// <summary>
        /// Gets or sets the instance of the MainVM to update the TestView
        /// </summary>

        public MainVM MainVM {
            [DebuggerNonUserCode]
            get { return this.mainVM; }
            [DebuggerNonUserCode]
            set {
                if (this.mainVM != value) {
                    this.mainVM = value;
                    SetPropertyChanged("MainVM");
                }
            }
        }

        #endregion

        #endregion Properties

        #region Commands

        private ICommand _UpdateViewCmd;
        public ICommand UpdateViewCmd {
            get {
                if (_UpdateViewCmd == null) {
                    _UpdateViewCmd = CreateCommand(UpdateView);
                }
                return _UpdateViewCmd;
            }
        }

        #endregion

        #region Events



        #endregion Events

        #region Methods

        public void LoadConfiguration(bool showMessage = true) {
            if (showMessage) {
                if (MessageBox.Show("Are you sure you want to load the Configuration from the file?", "Load Configuration?", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                    load();
                }
            } else {
                load();
            }
        }

        private void load() {
            Task.Factory.StartNew(() => {
                try {
                    SetBusy(true, "Loading Configuration...");

                    if (!File.Exists(ConfigFile)) {
                        File.Create(ConfigFile).Close();
                    }

                    try {
                        var SerializedObject = File.ReadAllText(ConfigFile);
                        if (SerializedObject.Length != 0) {
                            var bytes = SerializedObject.ToDecompressedJSON64<byte[]>();
                            Properties = BsonSerializer.Deserialize<TemplateControlProperties>(bytes);
                        }
                    } catch (Exception ex) {
                        MessageBox.Show($"Failed to Load the properties from the Configuration File: {ex.Message}", "Failed to load Configuration");
                    }
                    if (Properties == null) {
                        Properties = new TemplateControlProperties();
                    }
                    SetBusy(false, "Done Loading");
                    properties.IsTesting = true;
                    properties.ConfigFile = ConfigFile;

                    MainVM.Properties = properties;
                    MainVM.Initialise();
                } catch (Exception ex) {
                    ex.CustomLog();
                    SetBusy(false);
                }
            }).ContinueWith((t) => {
                InvokeOnUIThread(() => {
                    if (properties != null)
                        PropertyGrid.SelectedObject = Properties;
                    else
                        PropertyGrid.SelectedObject = new TemplateControlProperties();
                });
            });
        }

        public void SaveConfiguration() {
            if (MessageBox.Show("Are you sure you want to Save the current Configuration?", "Save Configuration?", MessageBoxButtons.YesNo) == DialogResult.Yes) {
                var serialized = BsonSerializer.Serialize(properties, false).ToCompressedJSON64();
                File.WriteAllText(ConfigFile, serialized);
            }
        }

        private void copyConfiguration() {
            try {
                Clipboard.SetText(BsonSerializer.Serialize(properties, false).ToCompressedJSON64());
            } catch (Exception ex) {
                MessageBox.Show($"Failed to Copy the Properties: {ex.Message}", "Failed to Copy");
                ex.CustomLog();
            }
        }

        private void pasteConfiguration() {
            try {
                var bytes = Clipboard.GetText().ToDecompressedJSON64<byte[]>();
                Properties = BsonSerializer.Deserialize<TemplateControlProperties>(bytes);
                PropertyGrid.SelectedObject = Properties;
                PropertyGrid.Refresh();
            } catch (Exception ex) {
                MessageBox.Show($"Failed to Paste the Configuration: {ex.Message}", "Failed to Paste");
            }
        }

        public void UpdateView(object obj) {
            this.MainVM?.Close();
            MainVM = new MainVM() { TestString = properties.HelloWorld };
            MainVM.Properties = properties;
            MainVM.Initialise();
        }

        public override string ToString() {
            return "Test Application";
        }

        #endregion Methods

        #region PropertyGrid Enhancements

        private void addControls(Control control) {
            ToolStrip strip = control as ToolStrip;
            if (strip != null) {
                setFont();
                var copy = new ToolStripButton("Copy");
                copy.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
                copy.ToolTipText = "Copies the Configuration";
                copy.Font = fontAwesome;
                copy.Text = "\uf0c5";
                copy.Click += new EventHandler((o, s) => copyConfiguration());

                var paste = new ToolStripButton("Paste");
                paste.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
                paste.ToolTipText = "Paste the Configuration";
                paste.Font = fontAwesome;
                paste.Text = "\uf054";
                paste.Click += new EventHandler((o, s) => pasteConfiguration());

                strip.Items.Add(new ToolStripSeparator());
                strip.Items.Add(copy);
                strip.Items.Add(paste);

                var save = new ToolStripButton("Save");
                save.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
                save.Font = fontAwesome;
                save.ToolTipText = "Saves the Configuration to the Local path.";
                save.Text = "\uf0c7";
                save.Click += new EventHandler((o, s) => SaveConfiguration());

                var load = new ToolStripButton("Load");
                load.DisplayStyle = ToolStripItemDisplayStyle.ImageAndText;
                load.ToolTipText = "Loads the Configuration from the Local path.";
                load.Font = fontAwesome;
                load.Text = "\uf07c";
                load.Click += new EventHandler((o, s) => LoadConfiguration());

                strip.Items.Add(new ToolStripSeparator());
                strip.Items.Add(save);
                strip.Items.Add(load);
            }

            foreach (Control child in control.Controls) {
                addControls(child);
            }
        }

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        private static extern IntPtr AddFontMemResourceEx(IntPtr pbFont, uint cbFont,
            IntPtr pdv, [System.Runtime.InteropServices.In] ref uint pcFonts);

        private PrivateFontCollection fonts = new PrivateFontCollection();

        Font fontAwesome;

        private void setFont() {
            byte[] fontData = $safeprojectname$.Properties.Resources.fontAwesome;
            IntPtr fontPtr = System.Runtime.InteropServices.Marshal.AllocCoTaskMem(fontData.Length);
            System.Runtime.InteropServices.Marshal.Copy(fontData, 0, fontPtr, fontData.Length);
            uint dummy = 0;
            fonts.AddMemoryFont(fontPtr, $safeprojectname$.Properties.Resources.fontAwesome.Length);
            AddFontMemResourceEx(fontPtr, (uint)$safeprojectname$.Properties.Resources.fontAwesome.Length, IntPtr.Zero, ref dummy);
            System.Runtime.InteropServices.Marshal.FreeCoTaskMem(fontPtr);

            fontAwesome = new Font(fonts.Families[0], 10.0F);
        }

        #endregion

    }
}
