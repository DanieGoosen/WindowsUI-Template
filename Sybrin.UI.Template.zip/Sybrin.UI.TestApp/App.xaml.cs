﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using Sybrin.UI.Template.ViewModels;
using Sybrin.UI.Template.PropertyClasses;

namespace $safeprojectname$ {
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {
        protected override void OnStartup(StartupEventArgs e) {
            base.OnStartup(e);

            launchScreen();
        }

        private void launchScreen() {
            using (var window = new TestWindow()) {
                var mainVM = new MainVM();
                var testVM = new TestVM(mainVM, window.PropertyGrid);
                window.DataContext = testVM;

                testVM.LoadConfiguration(false);

                window.ShowDialog();
            }
        }
    }
}
